import{A as e,B as t,D as n,F as r,H as i,I as a,K as o,O as s,S as c,U as l,V as u,W as d,X as f,Z as p,b as m,c as ee,et as h,l as te,n as ne,o as re,p as ie,q as ae,s as g,tt as _,u as oe,v as se,w as v,x as y,y as ce,z as b}from"../chunks/tersRYtB.js";import"../chunks/xihTtKlq.js";import{t as le}from"../chunks/E61fvIwO.js";import{t as ue}from"../chunks/CgJPDDU6.js";import{r as x}from"../chunks/R1Atr6Y8.js";import{r as de,t as fe}from"../chunks/CT0BeJHU.js";import{t as S}from"../chunks/Ylk43ZCb.js";function pe(e){let{invoice:t,booking:n,business:r,venueName:i}=e,a=Array.isArray(t.line_items)?t.line_items:JSON.parse(t.line_items||`[]`);function o(e){return`₹`+(e||0).toLocaleString(`en-IN`,{minimumFractionDigits:2})}function s(e){return e?new Date(e).toLocaleDateString(`en-IN`,{day:`numeric`,month:`long`,year:`numeric`}):`—`}let c=`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<title>Invoice ${t.invoice_no}</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, sans-serif; font-size: 13px; color: #111; background: #fff; padding: 40px; }
  .header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:32px; padding-bottom:20px; border-bottom:3px solid #128C7E; }
  .biz-name { font-size:24px; font-weight:700; color:#128C7E; margin-bottom:4px; }
  .biz-detail { font-size:12px; color:#555; line-height:1.6; }
  .invoice-meta { text-align:right; }
  .invoice-title { font-size:28px; font-weight:700; color:#128C7E; letter-spacing:2px; margin-bottom:8px; }
  .invoice-num { font-size:14px; font-weight:600; color:#333; }
  .invoice-date { font-size:12px; color:#777; margin-top:4px; }
  .status-badge { display:inline-block; padding:3px 12px; border-radius:20px; font-size:11px; font-weight:700; margin-top:6px; text-transform:uppercase; letter-spacing:0.05em; background:${t.status===`paid`?`#DCFCE7`:t.status===`sent`?`#FEF3C7`:`#F3F4F6`}; color:${t.status===`paid`?`#15803D`:t.status===`sent`?`#D97706`:`#374151`}; }
  .parties { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:28px; }
  .party-box { padding:16px; border-radius:8px; background:#F8FFFE; border:1px solid #E0F2F1; }
  .party-label { font-size:10px; font-weight:700; color:#128C7E; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:8px; }
  .party-name { font-size:15px; font-weight:600; color:#111; margin-bottom:4px; }
  .party-detail { font-size:12px; color:#555; line-height:1.6; }
  .event-box { background:#F0FDF4; border:1px solid #BBF7D0; border-radius:8px; padding:14px 18px; margin-bottom:24px; display:grid; grid-template-columns:repeat(4,1fr); gap:12px; }
  .event-item label { font-size:10px; color:#128C7E; font-weight:600; text-transform:uppercase; display:block; margin-bottom:2px; }
  .event-item span { font-size:13px; font-weight:500; color:#111; }
  table { width:100%; border-collapse:collapse; margin-bottom:20px; }
  thead { background:#128C7E; }
  thead th { color:#fff; padding:10px 12px; text-align:left; font-size:12px; font-weight:600; }
  thead th:last-child { text-align:right; }
  tbody tr:nth-child(even) { background:#F8FFFE; }
  tbody td { padding:10px 12px; font-size:13px; border-bottom:1px solid #E5E7EB; }
  tbody td:last-child { text-align:right; font-weight:500; }
  .totals { display:flex; justify-content:flex-end; margin-bottom:24px; }
  .totals-box { width:280px; }
  .totals-row { display:flex; justify-content:space-between; padding:6px 0; font-size:13px; border-bottom:1px solid #F0F0F0; }
  .totals-row.grand { font-size:16px; font-weight:700; color:#128C7E; border-bottom:2px solid #128C7E; border-top:2px solid #128C7E; padding:10px 0; margin-top:4px; }
  .totals-row.balance { font-size:14px; font-weight:700; color:${t.balance>0?`#D97706`:`#15803D`}; }
  .footer { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-top:24px; padding-top:20px; border-top:1px solid #E5E7EB; }
  .bank-box, .notes-box { padding:14px; background:#F9FAFB; border-radius:8px; border:1px solid #E5E7EB; }
  .box-label { font-size:10px; font-weight:700; color:#555; text-transform:uppercase; letter-spacing:0.06em; margin-bottom:8px; }
  .bank-row { display:flex; justify-content:space-between; font-size:12px; margin-bottom:4px; }
  .bank-row span:first-child { color:#777; }
  .bank-row span:last-child { font-weight:500; color:#111; }
  .upi-row { margin-top:8px; padding:8px; background:#E8F5E9; border-radius:6px; text-align:center; font-size:13px; font-weight:600; color:#128C7E; }
  .watermark { text-align:center; margin-top:32px; font-size:11px; color:#BBB; }
  @media print { body { padding:20px; } }
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <div>
    <div class="biz-name">${r.business_name}</div>
    <div class="biz-detail">
      ${r.address?r.address+`<br/>`:``}
      ${r.phone?`📞 `+r.phone:``}
      ${r.email?` &nbsp;·&nbsp; ✉ `+r.email:``}
      ${r.gst_number?`<br/>GST: `+r.gst_number:``}
      ${r.pan_number?` &nbsp;·&nbsp; PAN: `+r.pan_number:``}
    </div>
  </div>
  <div class="invoice-meta">
    <div class="invoice-title">INVOICE</div>
    <div class="invoice-num">${t.invoice_no}</div>
    <div class="invoice-date">Date: ${s(t.created||new Date().toISOString())}</div>
    <div><span class="status-badge">${t.status}</span></div>
  </div>
</div>

<!-- Parties -->
<div class="parties">
  <div class="party-box">
    <div class="party-label">Billed to</div>
    <div class="party-name">${n.customer_name}</div>
    <div class="party-detail">
      ${n.customer_phone?`📞 `+n.customer_phone:``}
    </div>
  </div>
  <div class="party-box">
    <div class="party-label">Venue</div>
    <div class="party-name">${i}</div>
    <div class="party-detail">${r.address||``}</div>
  </div>
</div>

<!-- Event details -->
<div class="event-box">
  <div class="event-item"><label>Event</label><span>${n.event_type}</span></div>
  <div class="event-item"><label>Date</label><span>${s(n.event_date)}</span></div>
  <div class="event-item"><label>Slot</label><span>${n.slot?.charAt(0).toUpperCase()+n.slot?.slice(1)}</span></div>
  <div class="event-item"><label>Guests</label><span>${n.guests}</span></div>
</div>

<!-- Line items -->
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Description</th>
      <th style="text-align:center">Qty</th>
      <th style="text-align:right">Rate</th>
      <th style="text-align:right">Amount</th>
    </tr>
  </thead>
  <tbody>
    ${a.map((e,t)=>`
      <tr>
        <td style="color:#999">${t+1}</td>
        <td>${e.description}</td>
        <td style="text-align:center">${e.qty}</td>
        <td style="text-align:right">${o(e.rate)}</td>
        <td style="text-align:right">${o(e.amount)}</td>
      </tr>
    `).join(``)}
  </tbody>
</table>

<!-- Totals -->
<div class="totals">
  <div class="totals-box">
    <div class="totals-row"><span>Subtotal</span><span>${o(t.subtotal)}</span></div>
    ${t.discount>0?`<div class="totals-row" style="color:#D97706"><span>Discount</span><span>− ${o(t.discount)}</span></div>`:``}
    ${t.gst_percent>0?`<div class="totals-row"><span>GST (${t.gst_percent}%)</span><span>${o(t.gst_amount)}</span></div>`:``}
    <div class="totals-row grand"><span>Total</span><span>${o(t.total)}</span></div>
    <div class="totals-row" style="color:#128C7E"><span>Amount paid</span><span>${o(t.paid)}</span></div>
    <div class="totals-row balance"><span>Balance due</span><span>${o(t.balance)}</span></div>
  </div>
</div>

<!-- Footer -->
<div class="footer">
  ${r.bank_name||r.upi_id?`
  <div class="bank-box">
    <div class="box-label">Payment details</div>
    ${r.bank_name?`<div class="bank-row"><span>Bank</span><span>${r.bank_name}</span></div>`:``}
    ${r.bank_account?`<div class="bank-row"><span>Account</span><span>${r.bank_account}</span></div>`:``}
    ${r.bank_ifsc?`<div class="bank-row"><span>IFSC</span><span>${r.bank_ifsc}</span></div>`:``}
    ${r.upi_id?`<div class="upi-row">UPI: ${r.upi_id}</div>`:``}
  </div>`:`<div></div>`}
  <div class="notes-box">
    <div class="box-label">Notes & terms</div>
    <div style="font-size:12px; color:#555; line-height:1.7;">
      ${t.notes||r.invoice_note||`Thank you for choosing us for your special event!`}
    </div>
    <div style="margin-top:12px; font-size:11px; color:#999;">This is a computer generated invoice.</div>
  </div>
</div>

<div class="watermark">Generated by BanquetOS · ${r.business_name}</div>

</body>
</html>`,l=window.open(``,`_blank`);l&&(l.document.write(c),l.document.close(),setTimeout(()=>l.print(),500))}function me(e,t,n){let r=`Dear ${t.customer_name},\n\nPlease find your invoice *${e.invoice_no}* for your ${t.event_type} on ${new Date(t.event_date).toLocaleDateString(`en-IN`,{day:`numeric`,month:`long`,year:`numeric`})}.\n\n*Total: ₹${e.total?.toLocaleString(`en-IN`)}*\n*Paid: ₹${e.paid?.toLocaleString(`en-IN`)}*\n*Balance: ₹${e.balance?.toLocaleString(`en-IN`)}*\n\nThank you for your booking!\n\n_BanquetOS_`,i=`https://wa.me/91${n.replace(/\D/g,``)}?text=${encodeURIComponent(r)}`;window.open(i,`_blank`)}var he=v(`<div class="alert success svelte-8jvsut"> </div>`),ge=v(`<a href="/settings/business" style="color:var(--danger);font-weight:600;">→ Setup now</a>`),_e=v(`<div class="alert danger svelte-8jvsut"> <!></div>`),C=v(`<div class="card" style="padding:16px; border:1px solid var(--warning); background:#FFFBEB;"><div style="font-size:13px; font-weight:600; color:var(--warning); margin-bottom:4px;">⚠ Business profile not set up</div> <p style="font-size:12px; color:var(--text-2); margin-bottom:10px;">Add your business name, GST number, and bank details for professional invoices.</p> <a href="/settings/business" class="btn-primary" style="font-size:12px; padding:7px 14px; text-decoration:none; display:inline-flex;">Setup Business Profile →</a></div>`),w=v(`<div style="text-align:center; padding:40px; color:var(--text-3);">Loading...</div>`),ve=v(`<div class="line-row svelte-8jvsut"><input class="desc-input svelte-8jvsut" placeholder="Description"/> <input class="num-input svelte-8jvsut" type="number" min="1" style="width:60px;text-align:center;"/> <input class="num-input svelte-8jvsut" type="number" min="0" style="width:100px;text-align:right;"/> <div style="width:100px;text-align:right;font-size:13px;font-weight:600;color:var(--text-1);padding:8px 4px;"> </div> <button style="width:30px;background:none;border:none;cursor:pointer;color:var(--danger);font-size:18px;padding:0;">×</button></div>`),ye=v(`<div class="total-row svelte-8jvsut" style="color:var(--warning);"><span>Discount</span><span> </span></div>`),be=v(`<div class="total-row svelte-8jvsut"><span> </span><span> </span></div>`),xe=v(`<div class="card" style="padding:14px 16px; display:flex; gap:12px; align-items:center; background:#F0FDF4; border-color:#BBF7D0;"><div style="flex:1; min-width:0;"><div style="font-size:14px; font-weight:600; color:var(--text-1);"> </div> <div style="font-size:12px; color:var(--text-2); margin-top:2px;"> </div></div> <div style="text-align:right; flex-shrink:0;"><div style="font-size:13px; color:var(--success); font-weight:600;"> </div> <div style="font-size:12px; color:var(--text-3);"> </div></div></div> <div class="card" style="padding:16px;"><div style="font-size:13px; font-weight:600; color:var(--text-1); margin-bottom:12px;">Line items</div> <div class="line-header svelte-8jvsut"><span style="flex:3;">Description</span> <span style="width:60px;text-align:center;">Qty</span> <span style="width:100px;text-align:right;">Rate</span> <span style="width:100px;text-align:right;">Amount</span> <span style="width:30px;"></span></div> <!> <button style="margin-top:8px;padding:8px 16px;background:var(--surface-alt);border:1px dashed var(--border);border-radius:var(--radius-sm);color:var(--primary);font-size:13px;font-weight:500;cursor:pointer;font-family:var(--font);width:100%;">+ Add line item</button></div> <div class="card" style="padding:16px;"><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;"><div class="field svelte-8jvsut"><span class="fl svelte-8jvsut">Discount (₹)</span><input type="number" min="0"/></div> <div class="field svelte-8jvsut"><span class="fl svelte-8jvsut">GST %</span> <select><option>No GST</option><option>5%</option><option>12%</option><option>18%</option><option>28%</option></select></div></div> <div style="border-top:1px solid var(--border-light);padding-top:12px;"><div class="total-row svelte-8jvsut"><span>Subtotal</span><span> </span></div> <!> <!> <div class="total-row grand svelte-8jvsut"><span>Total</span><span> </span></div> <div class="total-row svelte-8jvsut" style="color:var(--success);"><span>Amount paid</span><span> </span></div> <div class="total-row svelte-8jvsut"><span>Balance due</span><span> </span></div></div></div> <div class="card" style="padding:16px;display:flex;flex-direction:column;gap:12px;"><div class="field svelte-8jvsut"><span class="fl svelte-8jvsut">Notes / payment terms</span><textarea rows="3" placeholder="Payment due before event date..."></textarea></div> <div class="field svelte-8jvsut"><span class="fl svelte-8jvsut">Status</span> <select><option>Draft</option><option>Sent</option><option>Paid</option></select></div></div> <div class="action-row svelte-8jvsut"><button class="btn-ghost" style="flex:1;justify-content:center;"> </button> <button class="btn-primary" style="flex:1;justify-content:center;background:#075E54;">🖨 PDF</button> <button class="btn-primary" style="flex:2;justify-content:center;background:#25D366;">💬 WhatsApp</button></div>`,1),T=v(`<div class="page svelte-8jvsut"><div style="margin-bottom:4px;"><a style="font-size:13px; color:var(--primary); text-decoration:none;"> </a></div> <div class="page-header svelte-8jvsut"><div><h1 class="page-title svelte-8jvsut">Invoice</h1> <p class="page-sub svelte-8jvsut"> </p></div> <div style="display:flex; gap:8px; flex-wrap:wrap;"><button class="btn-ghost" style="font-size:13px; padding:8px 14px;">Save draft</button> <button class="btn-primary" style="font-size:13px; padding:8px 14px;">🖨 Print / PDF</button></div></div> <!> <!> <!> <!></div>`);function E(n,v){p(v,!0);let E=d(null),D=d(null),O=d(null),k=d(i([])),A=d(!0),j=d(!1),M=d(``),N=d(``),Se=d(!1),P=d(i([])),F=d(0),I=d(0),L=d(``),R=d(`draft`),z=o(()=>e(P).reduce((e,t)=>e+(t.amount||0),0)),B=o(()=>Math.round((e(z)-e(F))*e(I)/100)),V=o(()=>e(z)-e(F)+e(B)),H=o(()=>e(V)-(e(E)?.paid_amount||0));ne(async()=>{let t=le.params.id;try{await(async e=>{var t=_(e,2);l(O,t[0],!0),l(k,t[1],!0)})(await Promise.all([S(),x()]));let n=null,r=t;try{n=await ue.collection(`invoices`).getOne(t,{expand:`booking`}),r=n.booking,l(D,n,!0)}catch{l(Se,!0)}l(E,await ue.collection(`bookings`).getOne(r),!0),n?(l(P,typeof n.line_items==`string`?JSON.parse(n.line_items||`[]`):n.line_items||[],!0),l(F,n.discount||0,!0),l(I,n.gst_percent||0,!0),l(L,n.notes||``,!0),l(R,n.status||`draft`,!0)):(l(P,[{description:`${e(E)?.package||e(E)?.event_type} — Hall rent`,qty:1,rate:e(E)?.total_amount||0,amount:e(E)?.total_amount||0}],!0),l(L,e(O)?.invoice_note||``,!0))}catch(e){l(M,e.message,!0)}finally{l(A,!1)}});function Ce(){l(P,[...e(P),{description:``,qty:1,rate:0,amount:0}],!0)}function we(t){l(P,e(P).filter((e,n)=>n!==t),!0)}function Te(t,n,r){l(P,e(P).map((e,i)=>{if(i!==t)return e;let a={...e,[n]:r};return(n===`qty`||n===`rate`)&&(a.amount=Number(a.qty)*Number(a.rate)),n===`amount`&&(a.amount=Number(r)),a}),!0)}async function U(t=e(R)){if(e(E)){l(j,!0),l(M,``),l(N,``);try{let n=e(D)?.invoice_no||await fe(),r=await de({id:e(D)?.id,invoice_no:n,booking:e(E).id,line_items:e(P),subtotal:e(z),discount:e(F),gst_percent:e(I),gst_amount:e(B),total:e(V),paid:e(E).paid_amount||0,balance:e(H),notes:e(L),status:t});l(D,r,!0),l(R,t,!0),l(N,`Invoice saved!`)}catch(e){l(M,e.message,!0)}finally{l(j,!1)}}}function Ee(){if(!e(E)||!e(O)){l(M,`Please set up Business Profile first (Settings → Business Profile)`);return}let t=e(k).find(t=>t.id===e(E)?.venue)?.name||``;pe({invoice:{...e(D),invoice_no:e(D)?.invoice_no||`DRAFT`,line_items:e(P),subtotal:e(z),discount:e(F),gst_percent:e(I),gst_amount:e(B),total:e(V),paid:e(E).paid_amount||0,balance:e(H),notes:e(L),status:e(R)},booking:e(E),business:e(O),venueName:t})}function De(){if(e(E)){if(!e(D)){U();return}me(e(D),e(E),e(E).customer_phone||``)}}function W(e){return`₹`+(e||0).toLocaleString(`en-IN`)}function Oe(t){return e(k).find(e=>e.id===t)?.name||``}a(()=>{(e(N)||e(M))&&setTimeout(()=>{l(N,``),l(M,``)},3e3)});var G=T(),K=b(G),q=b(K),J=b(q);h(q),h(K);var Y=u(K,2),ke=b(Y),X=u(b(ke),2),Ae=b(X);h(X),h(ke);var je=u(ke,2),Z=b(je),Me=u(Z,2);h(je),h(Y);var Ne=u(Y,2),Pe=t=>{var n=he(),i=b(n);h(n),r(()=>y(i,`✓ ${e(N)??``}`)),c(t,n)};m(Ne,t=>{e(N)&&t(Pe)});var Q=u(Ne,2),Fe=t=>{var n=_e(),i=b(n),a=u(i),s=e=>{c(e,ge())},l=o(()=>e(M).includes(`Business Profile`));m(a,t=>{e(l)&&t(s)}),h(n),r(()=>y(i,`⚠ ${e(M)??``} `)),c(t,n)};m(Q,t=>{e(M)&&t(Fe)});var Ie=u(Q,2),Le=e=>{c(e,C())};m(Ie,t=>{e(O)||t(Le)});var Re=u(Ie,2),ze=e=>{c(e,w())},Be=n=>{var i=xe(),a=t(i),o=b(a),d=b(o),f=b(d,!0);h(d);var p=u(d,2),ee=b(p);h(p),h(o);var ne=u(o,2),_=b(ne),v=b(_);h(_);var le=u(_,2),ue=b(le);h(le),h(ne),h(a);var x=u(a,2),de=u(b(x),4);se(de,17,()=>e(P),ce,(t,n,i)=>{var a=ve(),o=b(a);g(o);var l=u(o,2);g(l);var d=u(l,2);g(d);var f=u(d,2),p=b(f,!0);h(f);var m=u(f,2);h(a),r(t=>{te(o,e(n).description),te(l,e(n).qty),te(d,e(n).rate),y(p,t)},[()=>W(e(n).amount)]),s(`input`,o,e=>Te(i,`description`,e.target.value)),s(`input`,l,e=>Te(i,`qty`,+e.target.value)),s(`input`,d,e=>Te(i,`rate`,+e.target.value)),s(`click`,m,()=>we(i)),c(t,a)});var fe=u(de,2);h(x);var S=u(x,2),pe=b(S),me=b(pe),he=u(b(me));g(he),h(me);var ge=u(me,2),_e=u(b(ge),2),C=b(_e);C.value=C.__value=0;var w=u(C);w.value=w.__value=5;var T=u(w);T.value=T.__value=12;var D=u(T);D.value=D.__value=18;var O=u(D);O.value=O.__value=28,h(_e),h(ge),h(pe);var k=u(pe,2),A=b(k),M=u(b(A)),N=b(M,!0);h(M),h(A);var Se=u(A,2),G=t=>{var n=ye(),i=u(b(n)),a=b(i);h(i),h(n),r(e=>y(a,`− ${e??``}`),[()=>W(e(F))]),c(t,n)};m(Se,t=>{e(F)>0&&t(G)});var K=u(Se,2),q=t=>{var n=be(),i=b(n),a=b(i);h(i);var o=u(i),s=b(o,!0);h(o),h(n),r(t=>{y(a,`GST (${e(I)??``}%)`),y(s,t)},[()=>W(e(B))]),c(t,n)};m(K,t=>{e(I)>0&&t(q)});var J=u(K,2),Y=u(b(J)),ke=b(Y,!0);h(Y),h(J);var X=u(J,2),Ae=u(b(X)),je=b(Ae,!0);h(Ae),h(X);var Z=u(X,2),Me=u(b(Z)),Ne=b(Me,!0);h(Me),h(Z),h(k),h(S);var Pe=u(S,2),Q=b(Pe),Fe=u(b(Q));ae(Fe),h(Q);var Ie=u(Q,2),Le=u(b(Ie),2),Re=b(Le);Re.value=Re.__value=`draft`;var ze=u(Re);ze.value=ze.__value=`sent`;var Be=u(ze);Be.value=Be.__value=`paid`,h(Le),h(Ie),h(Pe);var Ve=u(Pe,2),$=b(Ve),He=b($,!0);h($);var Ue=u($,2),We=u(Ue,2);h(Ve),r((t,n,r,i,a,o,s,c)=>{y(f,e(E).customer_name),y(ee,`${e(E).event_type??``} · ${t??``} · ${n??``}`),y(v,`Paid: ${r??``}`),y(ue,`Total: ${i??``}`),y(N,a),y(ke,o),y(je,s),ie(Z,`font-weight:700;color:${e(H)>0?`var(--warning)`:`var(--success)`};font-size:15px;`),y(Ne,c),$.disabled=e(j),y(He,e(j)?`Saving...`:`Save draft`)},[()=>Oe(e(E).venue),()=>new Date(e(E).event_date).toLocaleDateString(`en-IN`,{day:`numeric`,month:`short`,year:`numeric`}),()=>W(e(E).paid_amount||0),()=>W(e(E).total_amount||0),()=>W(e(z)),()=>W(e(V)),()=>W(e(E).paid_amount||0),()=>W(e(H))]),s(`click`,fe,Ce),re(he,()=>e(F),e=>l(F,e)),oe(_e,()=>e(I),e=>l(I,e)),re(Fe,()=>e(L),e=>l(L,e)),oe(Le,()=>e(R),e=>l(R,e)),s(`click`,$,()=>U(`draft`)),s(`click`,Ue,Ee),s(`click`,We,()=>{U(`sent`),setTimeout(De,800)}),c(n,i)};m(Re,t=>{e(A)?t(ze):e(E)&&t(Be,1)}),h(G),r(()=>{ee(q,`href`,e(E)?`/bookings/${e(E).id}`:`/invoices`),y(J,`← ${e(E)?`Back to booking`:`All invoices`}`),y(Ae,`${(e(D)?.invoice_no||`New invoice`)??``}${e(E)?` · `+e(E).customer_name:``}`),Z.disabled=e(j)}),s(`click`,Z,()=>U(`draft`)),s(`click`,Me,Ee),c(n,G),f()}n([`click`,`input`]);export{E as component};