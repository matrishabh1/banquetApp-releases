/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const collection = new Collection({
    "id": "rvxbbc6nh0x0umj",
    "created": "2026-07-30 06:15:56.993Z",
    "updated": "2026-07-30 06:15:56.993Z",
    "name": "expenses",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "a4bcq7aq",
        "name": "date",
        "type": "date",
        "required": true,
        "presentable": false,
        "unique": false,
        "options": {
          "min": "",
          "max": ""
        }
      },
      {
        "system": false,
        "id": "nj14euib",
        "name": "category",
        "type": "select",
        "required": true,
        "presentable": false,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "values": [
            "staff_salary",
            "staff_daily_wage",
            "electricity",
            "water",
            "generator",
            "decoration_vendor",
            "catering_advance",
            "catering_final",
            "dj_sound",
            "photographer",
            "tent_furniture",
            "flower_mandap",
            "security_guard",
            "valet_parking",
            "housekeeping",
            "laundry",
            "maintenance_repair",
            "property_tax",
            "licence_fee",
            "marketing",
            "printing",
            "food_staff",
            "diesel",
            "ice",
            "crockery_rental",
            "miscellaneous"
          ]
        }
      },
      {
        "system": false,
        "id": "4upupfdg",
        "name": "amount",
        "type": "number",
        "required": true,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "noDecimal": false
        }
      },
      {
        "system": false,
        "id": "me3tdvwc",
        "name": "venue",
        "type": "relation",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "collectionId": "d0oxh0p1v6mirqv",
          "cascadeDelete": false,
          "minSelect": null,
          "maxSelect": 1,
          "displayFields": null
        }
      },
      {
        "system": false,
        "id": "au6snbwi",
        "name": "booking",
        "type": "relation",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "collectionId": "x9vmipwxhczl57m",
          "cascadeDelete": false,
          "minSelect": null,
          "maxSelect": 1,
          "displayFields": null
        }
      },
      {
        "system": false,
        "id": "izzsygta",
        "name": "paid_to",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "txigudjv",
        "name": "mode",
        "type": "select",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "maxSelect": 1,
          "values": [
            "cash",
            "upi",
            "bank",
            "cheque"
          ]
        }
      },
      {
        "system": false,
        "id": "im0pogap",
        "name": "note",
        "type": "text",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      },
      {
        "system": false,
        "id": "1h1t9vsg",
        "name": "is_recurring",
        "type": "bool",
        "required": false,
        "presentable": false,
        "unique": false,
        "options": {}
      }
    ],
    "indexes": [],
    "listRule": null,
    "viewRule": null,
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("rvxbbc6nh0x0umj");

  return dao.deleteCollection(collection);
})
