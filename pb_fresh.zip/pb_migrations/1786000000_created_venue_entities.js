/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = new Collection({
    "id": "ve1nt1ty0000001",
    "name": "venue_entities",
    "type": "base",
    "fields": [
      {
        "id": "ven_name",
        "name": "name",
        "type": "text",
        "required": true
      },
      {
        "id": "ven_venue",
        "name": "venue",
        "type": "relation",
        "required": true,
        "options": {
          "collectionId": "d0oxh0p1v6mirqv",
          "cascadeDelete": true,
          "maxSelect": 1
        }
      },
      {
        "id": "ven_capacity",
        "name": "capacity",
        "type": "number",
        "required": false
      },
      {
        "id": "ven_active",
        "name": "active",
        "type": "bool",
        "required": false
      }
    ],
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": ""
  });

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("ve1nt1ty0000001");
  return app.delete(collection);
});
