/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  // Skip if already exists
  try {
    app.findCollectionByNameOrId("venue_entities");
    return; // already exists, skip
  } catch(e) {}

  const venuesCollection = app.findCollectionByNameOrId("venues");

  const collection = new Collection({
    "id": "ve1nt1ty0000001",
    "name": "venue_entities",
    "type": "base",
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": "",
    "fields": [
      {
        "name": "name",
        "type": "text",
        "required": true,
        "presentable": true
      },
      {
        "name": "venue",
        "type": "relation",
        "required": true,
        "options": {
          "collectionId": venuesCollection.id,
          "cascadeDelete": true,
          "maxSelect": 1
        }
      },
      {
        "name": "capacity",
        "type": "number",
        "required": false
      },
      {
        "name": "active",
        "type": "bool",
        "required": false
      }
    ]
  });

  app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("venue_entities");
    app.delete(collection);
  } catch(e) {}
});
