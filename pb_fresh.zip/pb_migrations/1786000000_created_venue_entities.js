/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  // Skip if already exists
  try {
    app.findCollectionByNameOrId("venue_entities");
    return;
  } catch(e) {}

  const venuesCollection = app.findCollectionByNameOrId("venues");

  const collection = new Collection({
    "name": "venue_entities",
    "type": "base",
    "listRule": "",
    "viewRule": "",
    "createRule": "",
    "updateRule": "",
    "deleteRule": ""
  });

  collection.fields.add(new Field({ "name": "name", "type": "text", "required": true, "presentable": true }));
  collection.fields.add(new Field({ "name": "venue", "type": "relation", "required": true, "collectionId": venuesCollection.id, "cascadeDelete": true, "maxSelect": 1 }));
  collection.fields.add(new Field({ "name": "capacity", "type": "number", "required": false }));
  collection.fields.add(new Field({ "name": "active", "type": "bool", "required": false }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("venue_entities");
    app.delete(collection);
  } catch(e) {}
});
