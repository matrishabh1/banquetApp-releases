/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("bookings");

  // Add end_date if not exists
  try {
    collection.fields.getByName("end_date");
  } catch(e) {
    collection.fields.add(new DateField({
      "name": "end_date",
      "required": false
    }));
  }

  // Add entities if not exists
  try {
    collection.fields.getByName("entities");
  } catch(e) {
    const entitiesCollection = app.findCollectionByNameOrId("venue_entities");
    collection.fields.add(new RelationField({
      "name": "entities",
      "required": false,
      "options": {
        "collectionId": entitiesCollection.id,
        "cascadeDelete": false,
        "maxSelect": null
      }
    }));
  }

  app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("bookings");
    collection.fields.removeByName("end_date");
    collection.fields.removeByName("entities");
    app.save(collection);
  } catch(e) {}
});
