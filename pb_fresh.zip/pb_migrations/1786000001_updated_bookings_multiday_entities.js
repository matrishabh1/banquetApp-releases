/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("x9vmipwxhczl57m");

  // Add end_date field
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bkg_end_date",
    "name": "end_date",
    "type": "date",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": { "min": "", "max": "" }
  }));

  // Add entities multi-relation field
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "bkg_entities",
    "name": "entities",
    "type": "relation",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "collectionId": "ve1nt1ty0000001",
      "cascadeDelete": false,
      "minSelect": null,
      "maxSelect": null,
      "displayFields": null
    }
  }));

  return dao.saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("x9vmipwxhczl57m");

  collection.schema.removeField("bkg_end_date");
  collection.schema.removeField("bkg_entities");

  return dao.saveCollection(collection);
});
