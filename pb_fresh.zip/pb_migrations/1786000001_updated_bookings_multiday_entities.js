/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("x9vmipwxhczl57m");

  collection.fields.add(new DateField({
    "id": "bkg_end_date",
    "name": "end_date",
    "required": false
  }));

  collection.fields.add(new RelationField({
    "id": "bkg_entities",
    "name": "entities",
    "required": false,
    "options": {
      "collectionId": "ve1nt1ty0000001",
      "cascadeDelete": false,
      "maxSelect": null
    }
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("x9vmipwxhczl57m");
  collection.fields.removeById("bkg_end_date");
  collection.fields.removeById("bkg_entities");
  return app.save(collection);
});
