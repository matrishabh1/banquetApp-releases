/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("bookings");

  // Add end_date if not exists
  try { collection.fields.getByName("end_date"); } catch(e) {
    collection.fields.add(new Field({ "name": "end_date", "type": "date", "required": false }));
  }

  // Add entities if not exists
  try { collection.fields.getByName("entities"); } catch(e) {
    const entitiesCollection = app.findCollectionByNameOrId("venue_entities");
    collection.fields.add(new Field({ "name": "entities", "type": "relation", "required": false, "collectionId": entitiesCollection.id, "cascadeDelete": false, "maxSelect": null }));
  }

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("bookings");
    try { const f = collection.fields.getByName("end_date"); collection.fields.removeById(f.id); } catch(e) {}
    try { const f = collection.fields.getByName("entities"); collection.fields.removeById(f.id); } catch(e) {}
    app.save(collection);
  } catch(e) {}
});
