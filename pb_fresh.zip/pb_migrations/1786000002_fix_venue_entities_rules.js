/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  try {
    const collection = app.findCollectionByNameOrId("venue_entities");
    collection.listRule = "";
    collection.viewRule = "";
    collection.createRule = "";
    collection.updateRule = "";
    collection.deleteRule = "";
    app.save(collection);
  } catch(e) {
    // Collection doesn't exist or save failed — skip silently
  }
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("venue_entities");
    collection.listRule = null;
    collection.viewRule = null;
    collection.createRule = null;
    collection.updateRule = null;
    collection.deleteRule = null;
    app.save(collection);
  } catch(e) {
    // skip
  }
});
